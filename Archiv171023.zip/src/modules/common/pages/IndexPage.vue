<template>
  <q-page class="q-pa-sm">
    <q-card class="q-mt-sm">
      <q-card-section>
        <div class="text-h6">Componentes básicos</div>
        <div class="text-subtitle2">by Gerhard Karl</div>
      </q-card-section>

      <q-card-section class="q-pt-none">
        <div class="row q-col-gutter-md">
          <div class="col-md-6">
            <q-list bordered class="rounded-borders">
              <q-item-label header>Inputs</q-item-label>
            </q-list>
          </div>
          <div class="col-md-6">
            <q-list bordered class="rounded-borders">
              <q-item-label header>Modais</q-item-label>
            </q-list>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
</script>
