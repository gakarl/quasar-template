const DEFAULT_COLOR = 'primary';

const input = {
  color: DEFAULT_COLOR,
  dense: true,
  'lazy-rules': true
}

export {
  input
}
